import pygame

width = 640
height = 480
size = width, height
pygame.init()
screen = pygame.display.set_mode(size)

pygame.display.flip()
